from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete con cálculos matemáticos",
	author="Jaime",
	author_email="jaime.abad.afonso@gmail.com",
	url="www.dominio.es",
	packages=["modulos", "modulos.calculos"]
	
)