# import funciones_matematicas 
# print( funciones_matematicas.suma(5,3) )

from funciones_matematicas import *

print( resta(9,5) )

print( multiplica(3,5) )