from calculos.calculos_generales import *

print( dividir(4,6) )
print( potencia(4,6) )

