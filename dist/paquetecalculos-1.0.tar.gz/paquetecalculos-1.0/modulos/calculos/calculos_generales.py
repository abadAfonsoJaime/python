def sumar(num1, num2):
	return num1+num2

def restar(num1, num2):
	return num1-num2

def multiplicar(num1, num2):
	return num1*num2

def dividir(dividendo, divisor):
	return dividendo/divisor

def potencia(base, exponente):
	return base**exponente

def redondear(numero):
	return round(numero)